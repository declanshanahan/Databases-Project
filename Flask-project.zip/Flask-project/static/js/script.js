document.addEventListener('DOMContentLoaded', () => {
  console.log('JavaScript is working!');
});
